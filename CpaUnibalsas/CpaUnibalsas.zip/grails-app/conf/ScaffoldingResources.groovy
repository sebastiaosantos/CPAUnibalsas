modules = {
	scaffolding {
		dependsOn 'bootstrap'
		resource url: 'css/scaffolding.css'
	}
}