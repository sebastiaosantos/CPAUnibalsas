package br.edu.unibalsas.siscpa

class Main {

    static constraints = {
    }
}
